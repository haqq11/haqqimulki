<?php
require 'functions.php';

// cek apakah tombol submit sudah ditekan atau belum
if( isset($_POST["submit"]) ) {
	// cek apakah data berhasil di tambahkan atau tidak
	if(tambah($_POST) > 0 ) {
		echo "
				<script>
					alert('data berhasil ditambahkan!');
					document.location.href = 'index.php';
				</script>
			 ";
	} else{
		echo "
				<script>
					alert('data gagal ditambahkan!');
					document.location.href = 'index.php';
				</script>
			 ";
	}
}

 ?>
<!DOCTYPE html>
<html>
<head>
	 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Aplikasi Penggajian Karyawan">
    <meta name="author" content="Hakko Bio Richard">
    <link rel="icon" href="../../favicon.ico">

    <title>Aplikasi Karyawan</title>

    <!-- Bootstrap core CSS -->
    <link href="dist/css/bootstrap.min.css" rel="stylesheet">
     <script src="dist/js/jquery-1.9.1.js"></script>
    <script src="dist/js/bootstrap.js"></script>

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet">
    <script src="assets/js/ie-emulation-modes-warning.js"></script>
    <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
	<title>Tambah data karyawan</title>
</head>
<body background="image/bg2.jpg">
<h1 class="panel">Tambah Data Karyawan</h1>
<div style="margin-left: 177px !important;" class="row">
<form action="" method="post">
	<ul>
		<li>
			<label for="nama">NIP : </label>
			<input type="text" class="form-control" name="id" id="id" required>
		</li>
		<li>
			<label for="nama">NAMA : </label>
			<input type="text" class="form-control" name="nama" id="nama" required>
		</li>
		<li>
			<label for="negara">NEGARA : </label>
			<input type="text" class="form-control" name="negara" id="negara" required>
		</li>
		<li>
			<label for="propinsi">PROVINSI : </label>
			<input type="text" class="form-control" name="propinsi" id="propinsi" required>
		</li>
		<li>
			<label for="kota">KOTA : </label>
			<input type="text" class="form-control" name="kota" id="kota" required>
		</li>
		<br>
			<button type="submit" class="form-control" name="submit" style="background-color: red;font-size: large;font-weight: bold;margin-left: 33% !important;margin-top: -23% !important;border-radius: 33px !important;">Klik Disini Untuk Tambah Data!</button>
		
	<ul>
</form>
</div>

</body>
</html>