<?php 
// session_start();
// if (empty($_SESSION['username'])){
// 	header('location:../index.html');	
// } else {
  require 'functions.php';
$karyawan = query("SELECT * FROM karyawan ORDER BY id DESC");

// tombol cari ditekan
if( isset($_POST["cari"]) ){
  $karyawan = cari($_POST["keyword"]);
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Aplikasi Karyawan">
    <meta name="author" content="haqqi">

    <title>Welcome Karyawan</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Add custom CSS here -->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <!-- Page Specific CSS -->
    <link rel="stylesheet" href="http://cdn.oesmith.co.uk/morris-0.4.3.min.css">
  </head>
  <body>
    <div id="wrapper">

      <!-- Sidebar -->
      <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Aplikasi Karyawan)</a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-ex1-collapse">
          <ul class="nav navbar-nav side-nav">
            <li class="active"><a href="index.php"><i class="fa fa-dashboard"></i> Data Karyawan</a></li>
            <!-- <li><a href="tampilgajiaja.php"><i class="fa fa-bar-chart-o"></i> Data Gaji Karyawan</a></li> -->
          </ul>

          <ul class="nav navbar-nav navbar-right navbar-user">
            
                <li><a href="../logout.php" onclick="return confirm('Apakah anda akan keluar?');"><i class="fa fa-power-off"></i> Keluar APeK</a></li>
              </ul>
            </li>
          </ul>
        </div><!-- /.navbar-collapse -->
      </nav>
      <?php
$timeout = 10; // Set timeout minutes
$logout_redirect_url = "../index.html"; // Set logout URL

$timeout = $timeout * 60; // Converts minutes to seconds
if (isset($_SESSION['start_time'])) {
    $elapsed_time = time() - $_SESSION['start_time'];
    if ($elapsed_time >= $timeout) {
        session_destroy();
        echo "<script>alert('Session Anda Telah Habis!'); window.location = '$logout_redirect_url'</script>";
    }
}
$_SESSION['start_time'] = time();
?>

      <div id="page-wrapper">

        <div class="row">
          <div class="col-lg-12">
            <h1>Halaman Utama <small>Admin</small></h1>
            <ol class="breadcrumb">
              <li class="active"><i class="fa fa-dashboard"></i> Halaman Utama </li>
            </ol>
            <table width="900">
            <tr>
            <td width="250"><div class="Tanggal"><h4><script language="JavaScript">document.write(tanggallengkap);</script></div></h4></td> 
            <td align="left" width="30"> - </td>
            <td align="left" width="620"> <h4><div id="output" class="jam" ></div></h4></td>
            </tr>
            </table>
            <br />
            <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
             Selamat Datang Di Halaman Admin APeK.. Untuk Hitung Lembur Karyawan dan Transfer Gaji Silahkan Klik Transfer Gaji..
          </div>
        </div><!-- /.row -->
        <div class="col-lg-12">
            <div class="panel panel-primary">
              <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-user"></i> Data Karyawan </h3> 
              </div>
              <form action="" method="post">
  <input type="text" name="keyword" size="60" autofocus placeholder="masukan keyword pencarian.." autocomplete="off">
  <button type="submit" name="cari">CARI!</button>
</form>
<br>
<table border="1" cellpadding="15" cellspacing="0">
  
  <tr>
    <th>No.</th>
    <th>NIP.</th>
    <th>Nama</th>
    <th>Negara</th>
    <th>Propinsi</th>
    <th>Kota</th>
  </tr>

<?php $i = 1; ?>
<?php foreach ($karyawan as $row ) : ?>

  <tr>
    <td><?= $i; ?></td>
    
    <td><?= $row["id"]; ?></td>
    <td><?= $row["nama"]; ?></td>
    <td><?= $row["negara"]; ?></td>
    <td><?= $row["propinsi"]; ?></td>
    <td><?= $row["kota"]; ?></td>
    <td>
      <a href="ubah.php?id=<?= $row["id"]; ?>">ubah</a>
      <a href="hapus.php?id=<?= $row["id"]; ?>" onclick="return confirm('anda yakin ingin menghapus data?');">hapus</a>
    </td>

  </tr>
<?php $i++; ?>
<?php endforeach; ?>
</table>
             
                        <br>
                                        <div style="margin-left: 61% !important;margin-top: -5% !important;" class="text-center">
                  <a href="tambah.php" class="btn btn-sm btn-warning">Tambah Data Karyawan <i class="fa fa-arrow-circle-center"></i></a>
              
                </div>
              </div> 
            </div>
          </div>
        </div><!-- /.row --> 

      </div><!-- /#page-wrapper -->

    </div><!-- /#wrapper -->

    <!-- JavaScript -->
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.js"></script>

    <!-- Page Specific Plugins -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="http://cdn.oesmith.co.uk/morris-0.4.3.min.js"></script>
    <script src="js/morris/chart-data-morris.js"></script>
    <script src="js/tablesorter/jquery.tablesorter.js"></script>
    <script src="js/tablesorter/tables.js"></script>

  </body>
</html>