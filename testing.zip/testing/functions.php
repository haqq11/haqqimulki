<?php 
$conn = mysqli_connect("localhost", "root", "", "teskerja");



function query($query) {
	global $conn;
	$result = mysqli_query($conn, $query);
	$rows = [];
	while( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}

function tambah($data) {
	global $conn;

	// $id = htmlspecialchars($data["id"]);
	$nama = htmlspecialchars($data["nama"]);
	$negara = htmlspecialchars($data["negara"]);
	$propinsi = htmlspecialchars($data["propinsi"]);
	$kota = htmlspecialchars($data["kota"]);


	$query = "INSERT INTO karyawan
				VALUES
				('', '$nama', '$negara', '$propinsi','$kota')
			";
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function hapus($id) {
	global $conn;
	mysqli_query($conn, "DELETE FROM karyawan WHERE id = $id");
	return mysqli_affected_rows($conn);
}

function ubah($data) {
	global $conn;

	$id = $data["id"];
	$nama = htmlspecialchars($data["nama"]);
	$negara = htmlspecialchars($data["negara"]);
	$propinsi = htmlspecialchars($data["propinsi"]);
	$kota = htmlspecialchars($data["kota"]);

	$query = "UPDATE karyawan SET
				nama = '$nama',
				negara = '$negara',
				propinsi = '$propinsi',
				kota = '$kota'
			WHERE id = $id
			";
				
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function cari($keyword) {
	$query = "SELECT * FROM karyawan
				WHERE
			  id LIKE '%$keyword%' OR
			  nama LIKE '%$keyword%' OR
			  negara LIKE '%$keyword%' OR
			  propinsi LIKE '%$keyword%' OR
			  kota LIKE '%$keyword%' 
		";
	return query($query);
}
function registrasi($data) {
	global $conn;

	$username = strtolower(stripslashes($data["username"]));
	$password = mysqli_real_escape_string($conn, $data["password"]);
	$password2 = mysqli_real_escape_string($conn, $data["password2"]);
	$email = mysqli_real_escape_string($conn, $data["email"]);


// cek username sudah ada atau belum
	$result = mysqli_query($conn, "SELECT username FROM user WHERE username = '$username'");
	if( mysqli_fetch_assoc($result) ) {
		echo "<script>
				alert('username sudah terdaftar!')
			  </script>";
		return false;
	}

// cek konfirmasi password
	if( $password !== $password2 ) {
		echo "<script>
				alert('konfirmasi password tidak sesuai!');
			  </script>";
		return false;
	}

// enkripsi password
	$password = password_hash($password, PASSWORD_DEFAULT);

// tambahkan user baru ke db
	mysqli_query($conn, "INSERT INTO user VALUES('', '$username', '$password', '$email')");

	return mysqli_affected_rows($conn);

}

 ?>
